let display = document.getElementById("display");

// Function to append numbers and operators to the display
function appendToDisplay(value) {
    display.innerText += value;
}

// Function to clear the display
function clearDisplay() {
    display.innerText = "";
}

// Function to evaluate the expression
function calculate() {
    try {
        display.innerText = eval(display.innerText); // Use JavaScript's eval function to evaluate the expression
    } catch (e) {
        display.innerText = "Error"; // Handle errors (e.g., invalid input)
    }
}
